/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tounge.twister;


public class SequenceDisplay {
    
    public static void main(String[] args) {
        System.out.println("Sequence of numbers:");
        for (int i = 100; i >0; i--) {
            if(i%11!=0){
                continue;
            }
            System.out.print(i + " ");
        }
    }
}

    

