/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tounge.twister;
import java.util.Scanner;
/**
 *
 * @author user
 */
public class PasswordSystem {
    


    private static final String PASSWORD = "pass1234"; // Replace with your password
    private static final int MAX_ATTEMPTS = 3; // Maximum number of attempts

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int attempts = 0;
        boolean authenticated = false;

        System.out.println("Welcome to the Password System!");

        while (attempts < MAX_ATTEMPTS && !authenticated) {
            System.out.print("Enter your password: ");
            String inputPassword = scanner.nextLine();

            if (validatePassword(inputPassword)) {
                authenticated = true;
                System.out.println("Password correct. Access granted.");
            } else {
                attempts++;
                if (attempts < MAX_ATTEMPTS) {
                    System.out.println("Incorrect password. You have " + (MAX_ATTEMPTS - attempts) + " attempts left.");
                } else {
                    System.out.println("Incorrect password. You have been locked out.");
                }
            }
        }

        scanner.close();
    }

    private static boolean validatePassword(String inputPassword) {
        return PASSWORD.equals(inputPassword);
    }
}

    

