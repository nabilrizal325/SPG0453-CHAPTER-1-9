package tounge.twister;
public class ToungeTwister {
    public static void main(String[] args) {
       String searchMe = "How much wood would a woodchuck chuck if a woodchuck could chuck wood?w";
       int max = searchMe.length();
       int numWs=0;
       for (int i=0; i<max; i++){
           if(searchMe.charAt(i)!='w')
               continue;
           numWs++;
       }
       System.out.println("Found "+numWs+" W's in the string");
    }
    
}
