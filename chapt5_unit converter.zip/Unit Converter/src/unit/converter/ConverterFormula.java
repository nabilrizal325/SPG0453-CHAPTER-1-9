/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unit.converter;



public class ConverterFormula {
    
     public void convertRmToUsd(double rm) {
        double usd = rm * 0.22845497;
        System.out.printf("RM %.2f = %.6f USD%n", rm, usd);
    }
     
     public void convertKgToG(double kg){
         double g = kg * 1000;
         System.out.printf("%.2f kg = %.2f g%n", kg, g);
     }
     public void convertCelsiusToKelvin(double celcius){
         double kelvin = celcius + 273.15;
         System.out.printf("%.2f Celsius = %.2f Kelvin%n", celcius, kelvin);
     }
}
