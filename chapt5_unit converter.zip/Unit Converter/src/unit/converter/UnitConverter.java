
package unit.converter;

import java.util.Scanner;

public class UnitConverter {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        Menu mainMenu = new Menu();
        ConverterFormula convFormula = new ConverterFormula();
        
        mainMenu.displayMenu();
        int choice = input.nextInt();
        
        System.out.print("Insert Amount/Quantity :  ");
        
        switch (choice) {
            case 1:
                // Money Converter: RM to USD
                double rm = input.nextDouble();
                convFormula.convertRmToUsd(rm);
               
                break;

            case 2:
                // Mass Converter: Kg to g
                
                double kg = input.nextDouble();
                convFormula.convertKgToG(kg);
                break;

            case 3:
                // Temperature Converter: Celsius to Kelvin
    
                double celcius = input.nextDouble();
                convFormula.convertCelsiusToKelvin(celcius);
            break;

            default:
                System.out.println("Invalid choice. Please select a valid option.");
        }
    }
    
}
