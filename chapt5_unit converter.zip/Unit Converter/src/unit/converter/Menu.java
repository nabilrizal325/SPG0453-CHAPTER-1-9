/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unit.converter;

/**
 *
 * @author user
 */
public class Menu {
    public void displayMenu(){
        System.out.println("Converter available :");
        System.out.println("1. Currency (MYR - USD)");
        System.out.println("2. Mass Converter (Kg - g)");
        System.out.println("3. Temperature Converter (Celsius - Kelvin)");
        System.out.print("Choose your converter : ");
    }
}
