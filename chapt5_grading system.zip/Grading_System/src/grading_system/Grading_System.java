package grading_system; // Declares the package for the class

import javax.swing.JOptionPane; // Imports the JOptionPane class for dialog boxes

public class Grading_System { // Defines the Grading_System class

    // Main method to run the program
    public static void main(String[] args) {
        Grading_System gradingSystem = new Grading_System(); // Create an instance of Grading_System
        String continueProgram; // Variable to store user input for continuing the program

        do { // Start of the do-while loop for repeated execution
            // Input number of students using JOptionPane
            String numStudentsInput = JOptionPane.showInputDialog(null, "Enter the number of students:"); // Prompt user for the number of students
            int numberOfStudents = Integer.parseInt(numStudentsInput); // Convert input to an integer

            // Create arrays to hold marks and grades
            int[] marks = new int[numberOfStudents]; // Array to store marks for each student
            char[] grades = new char[numberOfStudents]; // Array to store grades for each student

            // Input marks for each student using JOptionPane
            for (int i = 0; i < numberOfStudents; i++) { // Loop through each student
                String markInput = JOptionPane.showInputDialog(null, "Enter mark for student " + (i + 1) + ":"); // Prompt user for the mark
                marks[i] = Integer.parseInt(markInput); // Store the mark directly in the marks array
                grades[i] = gradingSystem.calculateGrade(marks[i]); //instance method to  calculate, Use  and store the grade
            }

            // Display results using an instance method
            gradingSystem.displayResults(marks, grades); // Call method to display results with marks and grades

            // Ask if the user wants to input another set of students
            continueProgram = JOptionPane.showInputDialog(null, "Would you like to input another set of students? (yes/no):"); // Prompt for continuation

        } while (continueProgram.equalsIgnoreCase("yes")); // Continue if the user inputs 'yes'
    }

    // Instance method to calculate the grade based on the mark
    char calculateGrade(int mark) {
        if (mark >= 85 && mark <= 100) { // Check if mark is between 85 and 100
            return 'A'; // Return grade A
        } else if (mark >= 70) { // Check if mark is between 70 and 84
            return 'B'; // Return grade B
        } else if (mark >= 50) { // Check if mark is between 50 and 69
            return 'C'; // Return grade C
        } else if (mark >= 40) { // Check if mark is between 40 and 49
            return 'D'; // Return grade D
        } else {
            return 'F'; // Return grade F for marks below 40
        }
    }

    // Instance method to display results
    void displayResults(int[] marks, char[] grades) {
        int passCount = 0; // Counter for passed students
        int failCount = 0; // Counter for failed students

        // Count pass and fail using for loop
        for (int i = 0; i < grades.length; i++) { // Loop through the grades array
            if (grades[i] == 'F') { // Check if the grade is F
                failCount++; // Increment fail count
            } else {
                passCount++; // Increment pass count
            }
        }

        // Display grade summary
        System.out.println("Grade Summary:"); // Print header for grade summary
        for (int i = 0; i < marks.length; i++) { // Loop through the marks array
            System.out.println("Student " + (i + 1) + ": Mark = " + marks[i] + ", Grade = " + grades[i]); // Print each student's mark and grade
        }

        System.out.println("Number of students who passed: " + passCount); // Print total passed students
        System.out.println("Number of students who failed: " + failCount); // Print total failed students

        // Bonus to instructor or not
        if (passCount > failCount) { // Check if more students passed than failed
            System.out.println("Bonus to instructor"); // Print bonus message if applicable
        } else {
            System.out.println("No bonus to instructor"); // Print no bonus message if applicable
        }
    }
}
