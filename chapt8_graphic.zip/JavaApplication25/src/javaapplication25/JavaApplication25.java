/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication25;

import java.awt.*;
import javax.swing.*;

public class JavaApplication25 extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setFont(new Font("Times New Roman", Font.BOLD+Font.ITALIC,24));
        g.drawString("CREEPER",10,20);
        g.setColor(Color.RED);
        g.drawLine(5, 30, 125, 30);
        
        // Creeper Head (square)
        g.setColor(new Color(83, 166, 83));  // Creeper green color
        g.fillRect(100, 50, 100, 100);       // Head (x, y, width, height)

        // Creeper Body (rectangle)
        g.setColor(new Color(83, 166, 83));  // Same Creeper green color
        g.fillRect(110, 150, 80, 150);       // Body (slightly narrower than head)

        // Creeper Legs (small rectangles)
        g.setColor(new Color(83, 166, 83));  // Same green color for legs
        g.fillRect(110, 300, 30, 50);        // Left front leg
        g.fillRect(160, 300, 30, 50);        // Right front leg
        g.fillRect(110, 350, 30, 50);        // Left back leg
        g.fillRect(160, 350, 30, 50);        // Right back leg

        // Creeper Face
        g.setColor(Color.BLACK);             // Face color (black for eyes and mouth)
        // Eyes
        g.fillRect(125, 80, 20, 20);         // Left eye
        g.fillRect(155, 80, 20, 20);         // Right eye
        // Mouth
        g.fillRect(135, 110, 30, 30);        // Mouth (large black rectangle)
        g.fillRect(125, 120, 10, 20);        // Left side of the mouth
        g.fillRect(165, 120, 10, 20);        // Right side of the mouth
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Creeper Drawing");
        JavaApplication25 creeperPanel = new JavaApplication25();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(creeperPanel);
        frame.setSize(400, 500);  // Adjust size to fit the creeper
        frame.setVisible(true);
    }
}






























