
package arithmeticprog; 
import java.util.Scanner;

public class PriceDiscountedItem {
    public static void main(String[] args){
        
        //declare the variable
        String itemName;
        double Price,totalPrice,discountedPrice;
        double discountRate;
        double quantity,priceAfterDiscount;
        int discountType;
        
        //declare the scanner function in the scanner library
        Scanner price = new Scanner(System.in);
        
        //ask for user input
        System.out.println("Enter item name");
        itemName = price.nextLine();
        
        System.out.println("Enter item price");
        Price = price.nextDouble();
        
        System.out.println("Enter item quantity");
        quantity = price.nextDouble();
        
        System.out.println("Choose item discount rate. Enter the number of your preferred colour \n1.Merah = 80% \n2.Biru = 60% \n3.Hijau = 40%");
        discountType = price.nextInt();
        
        //calculate total price
        totalPrice = Price * quantity;
        
        //use switch statement to calculate price after discount from user input
        switch (discountType){
            case 1:
                discountRate = 0.8;
                discountedPrice = totalPrice * discountRate;
                priceAfterDiscount = totalPrice - discountedPrice;break;
            case 2:
                discountRate = 0.6;
                discountedPrice = totalPrice * discountRate;
                priceAfterDiscount = totalPrice - discountedPrice;break;
            case 3:
                discountRate = 0.4;                
                discountedPrice = totalPrice * discountRate;
                priceAfterDiscount = totalPrice - discountedPrice;break;
            default:
                System.out.println("Invalid discount rate selected.");
                return;
        }
        
        //display the output
        System.out.println("Item Name : "+itemName);
        System.out.println("Price : "+Price);
        System.out.println("Quantity : "+quantity);
        System.out.println("Total Price : "+totalPrice);
        System.out.println("Discount Rate : "+discountRate);
        
        //use String.format("%.2f" to limit the decimal into only 2 decimal
        System.out.printf("Price After Discount : "+ String.format("%.2f", priceAfterDiscount)); 
    }
    
}
 