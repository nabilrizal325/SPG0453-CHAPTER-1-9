
package arithmeticprog;
import java.util.Scanner;

public class ArithmeticProg {

    public static void main(String[] args) {
        
        //declare variable
        int Num1;
        int Num2;
        String operator;
        
        Scanner myNum = new Scanner(System.in);
        
        //user input
        System.out.println("Choose your preferred operator.\nType +, -, x OR /");
        operator = myNum.nextLine();
        
        System.out.println("Enter first integer");
        Num1 = myNum.nextInt();
        
        System.out.println("Enter second integer");
        Num2 = myNum.nextInt();
        myNum.close();
        

        //declare and calculate the user input    
        int add = Num1 + Num2;
        int sub = Num1 - Num2;
        int multiply = Num1 * Num2;
        int divide = Num1 / Num2;
        int modulos = Num1 % Num2;
        
        //display the output based on user choosen operator
        switch(operator){
            case "+":
                System.out.println("Your answer is : " +add);break;
            case "-":
                System.out.println("Your answer is : " +sub);break;
            case "x":
                System.out.println("Your answer is : " +multiply);break;
            case "/":
                System.out.println("Your answer is : " +divide);break;
        }
        

    }        

    
}
