
package arithmeticprog;


public class CompoundProg {
    public static void main(String[] args) {
        int i = 5;
        System.out.println("Initial value of i: " + i);

        // Pre-increment
        System.out.println("\nPre-increment (++i):");
        System.out.println("Before increment: " + i);
        System.out.println("During increment: " + (++i)); // i is incremented first, then used
        System.out.println("After increment: " + i);

        // Reset i to 5
        i = 5;
        System.out.println("\nReset value of i: " + i);

        // Post-increment
        System.out.println("\nPost-increment (i++):");
        System.out.println("Before increment: " + i);
        System.out.println("During increment: " + (i++)); // i is used first, then incremented
        System.out.println("After increment: " + i);

        // Reset i to 5
        i = 5;
        System.out.println("\nReset value of i: " + i);

        // Pre-decrement
        System.out.println("\nPre-decrement (--i):");
        System.out.println("Before decrement: " + i);
        System.out.println("During decrement: " + (--i)); // i is decremented first, then used
        System.out.println("After decrement: " + i);

        // Reset i to 5
        i = 5;
        System.out.println("\nReset value of i: " + i);

        // Post-decrement
        System.out.println("\nPost-decrement (i--):");
        System.out.println("Before decrement: " + i);
        System.out.println("During decrement: " + (i--)); // i is used first, then decremented
        System.out.println("After decrement: " + i);
    }
}

