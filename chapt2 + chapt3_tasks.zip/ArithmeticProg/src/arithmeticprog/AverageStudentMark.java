
package arithmeticprog;
import java.util.Scanner;

public class AverageStudentMark {
    public static void main(String[] args){
        
        String name,subject,id;
        int test1,test2,averageMark;
        
        Scanner mark = new Scanner(System.in);
        
        System.out.println("Enter student name");
        name = mark.nextLine();
        
        System.out.println("Enter student id");
        id = mark.nextLine();
        
        System.out.println("Enter subject name");
        subject = mark.nextLine();

        System.out.println("Enter Test 1 mark");
        test1 = mark.nextInt();
        
        System.out.println("Enter test 2 mark");
        test2 = mark.nextInt();
        
        averageMark = (test1 + test2) / 2;
        
        System.out.println("Name : "+name);
        System.out.println("ID : "+id);
        System.out.println("Subject : "+subject);
        System.out.println("Average Mark : "+averageMark);
        
    }
    
}
