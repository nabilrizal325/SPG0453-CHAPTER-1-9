
package arithmeticprog;
import java.util.Scanner;
import java.util.InputMismatchException;


public class BMI {
        public static void main(String[] args){
            
            double BMI;
            
            Scanner scanner = new Scanner(System.in);
            
          
        double weight = 0;
        double height = 0;

        // Get weight input
        while (true) {
            try {
                System.out.println("Enter your weight in kg");
                weight = scanner.nextDouble();
                if (weight <= 0) {
                    System.out.println("Weight must be greater than 0. Please try again.");
                    continue;
                }
                break;  // Exit loop if input is valid
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a valid number for weight.");
                scanner.nextLine();  // Clear the buffer
            }
        }

        // Get height input
        while (true) {
            try {
                System.out.println("Enter your height in m");
                height = scanner.nextDouble();
                if (height <= 0) {
                    System.out.println("Height must be greater than 0. Please try again.");
                    continue;
                }
                break;  // Exit loop if input is valid
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a valid number for height.");
                scanner.nextLine();  // Clear the buffer
            }
        }

        System.out.println("Weight: " + weight + " kg");
        System.out.println("Height: " + height + " m");
    


            
            BMI = weight / Math.pow(height, 2);
            
            System.out.println("Weight : "+weight);
            System.out.println("Height : "+height);
            System.out.println("BMI : "+BMI);
            
            
         
            
        

    
}
}