
package arithmeticprog;
import java.util.Scanner;

public class UserInput {
    public static void main(String[] args){
        
        String Name,Hobby,FavoriteFood;
        int age;
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter your name");
        Name = scan.nextLine();
        
        System.out.println("Enter your age");
        age = scan.nextInt();
        scan.nextLine();
        
        System.out.println("Enter your hobby");
        Hobby = scan.nextLine();
        
        System.out.println("Enter your favorite food");
        FavoriteFood = scan.nextLine();
        
        System.out.println("Name : "+Name);
        System.out.println("Age : "+age);
        System.out.println("Hobby : "+Hobby);
        System.out.println("Favorite Food : "+FavoriteFood);
        
        scan.close();
    }
}
