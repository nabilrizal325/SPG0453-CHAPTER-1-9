
package arithmeticprog;
import java.util.Scanner;

public class CalculateAge {
    public static void main(String[] args){
        
        int currentYear;
        int bornYear;

        Scanner myYear = new Scanner(System.in);
        
        System.out.println("Enter the current year");
        currentYear = myYear.nextInt();
        
        System.out.println("Enter your born year");
        bornYear = myYear.nextInt();
        
        int age = currentYear - bornYear;
        
        System.out.println("Your age is : "+age);
                
        

}}
