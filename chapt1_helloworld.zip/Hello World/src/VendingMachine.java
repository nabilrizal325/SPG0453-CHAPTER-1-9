import java.util.Scanner; //library Scanner

public class VendingMachine { //class
    public static void main(String[] args){ //main (wajid ada)
        
        Scanner scan = new Scanner(System.in); //declare scanner from library

        // Product details
        // array number start with index zero
        String[] productNames = {"Roti Krim", "Roti Gardenia", "Roti Gardenia Jumbo"};
        double[] productPrices = {1.5, 3.0, 4.3};
      
        // Output the product list
        System.out.println("Welcome to the Simple Purchasing System");
        System.out.println("Available products:");
        //i is index
        for (int i = 0; i < 3; i++) {
            System.out.println((i + 1) + ". " + productNames[i] + " - RM" + productPrices[i]);
        }

        //input for what product
        System.out.println("Enter the number of product you want to buy:");
        int productNumber = scan.nextInt();

        //check if the input is valid or not
        if (productNumber < 1 || productNumber > productNames.length) {
            System.out.println("Invalid product number!");
            return;
        }

        //Product index
        int selectedProductIndex = productNumber - 1;

        //input for quantity
        System.out.println("Enter the quantity you want to buy:");
        int quantity = scan.nextInt();


        // Process the order
        double totalPrice = productPrices[selectedProductIndex] * quantity;
       

        // Output
        System.out.println("You have purchased " + quantity + " unit(s) of " + productNames[selectedProductIndex]);
        System.out.println("Total price: RM" + String.format("%.2f", totalPrice));
        System.out.println("Thank you for your purchase!");
    }
}

    


