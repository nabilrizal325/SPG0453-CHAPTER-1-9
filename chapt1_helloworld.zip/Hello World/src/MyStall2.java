/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class MyStall2 {
    
    public static void main(String[] args){
        
        System.out.println("-------------------------------------------------");
        System.out.println("|\t\t Welcome to My Stall \t\t|");
        System.out.println("-------------------------------------------------");
        System.out.println("|\t\t List of beverages \t\t|");
        System.out.println("|\t 1. Coconut Shake \t: RM 5.00 \t|");
        System.out.println("|\t 2. Kopi Ice      \t: RM 2.50 \t|");
        System.out.println("|\t 3. Nescafe Ice      \t: RM 4.00 \t|");
        System.out.println("_________________________________________________\n");
        
        System.out.println("Insert code of your desired drink : 1\n");
        System.out.println("Insert quantity : 2\n");
        System.out.println("Coconut Shake : RM 5\n");
        System.out.println("Total price : RM 10\n");


        
        
        
        
    }}
