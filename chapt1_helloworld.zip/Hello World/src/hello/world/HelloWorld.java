/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hello.world;

import javax.swing.JOptionPane;

public class HelloWorld {


    public static void main(String[] args) {
        
    //number 1
   /*     
        
        System.out.println("Hello World!!");
        
    //number 2
         System.out.println("Hai Dunia!!");
         
    //number 3
    
        System.out.print("Name : Muhammad Nabil Hakim bin Rizal ");
        System.out.print("Dream Job : Software Developer ");
        System.out.print("Interest : Sleeping");
        
    //number 4
    
        System.out.println("\nSoftware Engineering\nSemester 3 2024\nNasi Goreng Kicap");
        
    //number 5
        
        int x = 5+12;
        int y = 3-1;
        int z = 5/5;
        int a = 12*12;
        
        System.out.println("===== THIS IS ARITHMETICS OPERATORS =====\n");
        
        System.out.println("\t1. 5 + 12 = "+ x);
        System.out.println("\t2. 3 - 1 = "+ y);
        System.out.println("\t3. 5 / 5 = "+ z);
        System.out.println("\t4. 12 X 12 = "+ a);
        
        System.out.println("=========================================");*/
   int x=5;
   JOptionPane.showMessageDialog(null, "Hello World");
   JOptionPane.showMessageDialog(null, x);
    }
    
   


}
