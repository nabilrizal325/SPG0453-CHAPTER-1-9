/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KisMark;

import java.util.Scanner;

public class KisMark {
    public static void main(String[] args) {
        
        double lateNumber;
        double kisDeduct = 0.3;
        
        Scanner scanner = new Scanner (System.in);
        
        System.out.println("Enter the total amount of late number");
        lateNumber = scanner.nextDouble();
        
        if(lateNumber>3)
        {double deduction_kis = kisDeduct * lateNumber;
        
        System.out.println("Deduct mark is "+ deduction_kis);
        
        } else { System.out.println("Your total amount of late number is less than 3.Keep up the good work");
                
    }
        
        
    }
    
}
