/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KisMark;

import java.util.Scanner;

public class Grade {
     public static void main(String[] args) { //method yg wajib ada, klau tkdd, tkboleh run
        
         //declare variable
        int grade;
        
        //object bagi Scanner adalah scan
        Scanner scan = new Scanner(System.in);
        
        //user input
        System.out.println("Enter your mark"); //display instruction for user
        //input string type
        grade = scan.nextInt(); //input for grade
        
        //use the if...else if statement to display the grade based on user input
        if (grade>=80){
            System.out.println("Geade A"); //
        } else if (grade>=70) {
            System.out.println("Grade B"); 
        } else if (grade>=60) {
            System.out.println("Grade C"); 
        } else if (grade>=50) {
            System.out.println("Grade D"); 
        } else if (grade>=40) {
            System.out.println("Grade E"); 
        } else {
            System.out.println("Grade F"); 
        }
           
                
        
        
     
     }
}
