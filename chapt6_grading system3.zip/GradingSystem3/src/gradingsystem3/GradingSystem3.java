package gradingsystem3; // Package declaration for organizing related classes

import javax.swing.JOptionPane; // Importing JOptionPane for graphical user interface dialog boxes

public class GradingSystem3 {

    public static void main(String[] args) {
        String continueProgram; // Variable to control whether to continue the program

        // Loop to allow the user to enter multiple sets of student data
        do {
            // Input number of students using JOptionPane
            String numStudentsInput = JOptionPane.showInputDialog(null, "Enter the number of students:");
            int numberOfStudents = Integer.parseInt(numStudentsInput); // Convert input to integer

            // Create an array to hold student objects
            Student[] students = new Student[numberOfStudents]; // Array to store student data

            // Input marks for each student using JOptionPane
            for (int i = 0; i < numberOfStudents; i++) {
                // Prompt for each student's mark
                String markInput = JOptionPane.showInputDialog(null, "Enter mark for student " + (i + 1) + ":");
                int studentMark = Integer.parseInt(markInput); // Convert input to integer
                students[i] = new Student(studentMark); // Create a new Student object with the mark
            }

            // Create a GradeCalculator object and calculate grades
            GradeCalculator calculator = new GradeCalculator(students); // Pass students array to calculator
            calculator.calculateGrades(); // Calculate grades for the students

            // Output grade summary and pass/fail count to the console
            calculator.displayGradeSummary(); // Display grades summary
            calculator.displayPassFailCount(); // Display pass/fail count

            // Bonus to instructor or not based on pass/fail counts
            if (calculator.getPassCount() > calculator.getFailCount()) {
                System.out.println("Bonus to instructor"); // If more students passed
            } else {
                System.out.println("No bonus to instructor"); // If more students failed
            }

            // Ask if the user wants to input another set of students using JOptionPane
            continueProgram = JOptionPane.showInputDialog(null, "Would you like to input another set of students? (yes/no):");

        } while (continueProgram.equalsIgnoreCase("yes")); // Continue loop if the user responds with "yes"
    }
}

// Student class to hold mark and grade information
class Student {
    int mark; // Default access variable to store the student's mark
    char grade; // Default access variable to store the student's grade

    // Constructor to initialize the student's mark and calculate the grade
    public Student(int studentMark) { 
        mark = studentMark; // Set the mark
        grade = calculateGrade(); // Initialize grade based on mark
    }

    // Method to determine the grade based on the mark
    char calculateGrade() {
        if (mark >= 85 && mark <= 100) {
            return 'A'; // Grade A for marks 85-100
        } else if (mark >= 70 && mark < 85) {
            return 'B'; // Grade B for marks 70-84
        } else if (mark >= 50 && mark < 70) {
            return 'C'; // Grade C for marks 50-69
        } else if (mark >= 40 && mark < 50) {
            return 'D'; // Grade D for marks 40-49
        } else {
            return 'F'; // Grade F for marks below 40
        }
    }

    // Method to get the grade of the student
    char getGrade() {
        return grade; // Return the calculated grade
    }

    // Method to check if the student has passed
    boolean hasPassed() {
        return mark >= 40; // Return true if mark is 40 or higher
    }
}

// GradeCalculator class to process and calculate grades and statistics
class GradeCalculator {
    Student[] studentArray; // Array to hold student objects
    int gradeA, gradeB, gradeC, gradeD, gradeF; // Counters for each grade
    int passCount, failCount; // Counters for pass and fail

    // Constructor to initialize the GradeCalculator with the student array
    public GradeCalculator(Student[] inputStudents) { 
        studentArray = inputStudents; // Set the student array
        // Initialize grade counters to zero
        gradeA = 0;
        gradeB = 0;
        gradeC = 0;
        gradeD = 0;
        gradeF = 0;
        passCount = 0; // Initialize pass count to zero
        failCount = 0; // Initialize fail count to zero
    }

    // Method to calculate grades and pass/fail statistics
    void calculateGrades() {
        // Iterate through each student in the array
        for (Student student : studentArray) { 
            // Switch statement to count grades based on the student's grade
            switch (student.getGrade()) {
                case 'A':
                    gradeA++; // Increment grade A count
                    passCount++; // Increment pass count
                    break;
                case 'B':
                    gradeB++; // Increment grade B count
                    passCount++; // Increment pass count
                    break;
                case 'C':
                    gradeC++; // Increment grade C count
                    passCount++; // Increment pass count
                    break;
                case 'D':
                    gradeD++; // Increment grade D count
                    passCount++; // Increment pass count
                    break;
                case 'F':
                    gradeF++; // Increment grade F count
                    failCount++; // Increment fail count
                    break;
            }
        }
    }

    // Method to display the grade summary in the console
    void displayGradeSummary() {
        System.out.println("Grade Summary:");
        System.out.println("Grade A: " + gradeA); // Display number of grade A
        System.out.println("Grade B: " + gradeB); // Display number of grade B
        System.out.println("Grade C: " + gradeC); // Display number of grade C
        System.out.println("Grade D: " + gradeD); // Display number of grade D
        System.out.println("Grade F: " + gradeF); // Display number of grade F
    }

    // Method to display pass/fail counts in the console
    void displayPassFailCount() {
        System.out.println("Number of students who passed: " + passCount); // Display number of students who passed
        System.out.println("Number of students who failed: " + failCount); // Display number of students who failed
    }

    // Getters for pass and fail counts
    int getPassCount() {
        return passCount; // Return the number of students who passed
    }

    int getFailCount() {
        return failCount; // Return the number of students who failed
    }
}
