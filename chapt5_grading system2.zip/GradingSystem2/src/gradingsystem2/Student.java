package gradingsystem2;
public class Student {
    private int mark;
    private char grade;

    public Student(int mark) {
        this.mark = mark;
        this.grade = calculateGrade();
    }

    // Method to determine the grade based on the mark
    private char calculateGrade() {
        if (mark >= 85 && mark <= 100) {
            return 'A';
        } else if (mark >= 70 && mark < 85) {
            return 'B';
        } else if (mark >= 50 && mark < 70) {
            return 'C';
        } else if (mark >= 40 && mark < 50) {
            return 'D';
        } else {
            return 'F';
        }
    }

    public char getGrade() {
        return grade;
    }

    public boolean hasPassed() {
        return mark >= 40;
    }

}
