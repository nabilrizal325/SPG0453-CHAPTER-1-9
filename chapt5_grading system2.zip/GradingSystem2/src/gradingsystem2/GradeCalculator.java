package gradingsystem2;
import javax.swing.JOptionPane;

public class GradeCalculator {
    private Student[] students;
    private int gradeA, gradeB, gradeC, gradeD, gradeF;
    private int passCount, failCount;

    public GradeCalculator(Student[] students) {
        this.students = students;
        this.gradeA = 0;
        this.gradeB = 0;
        this.gradeC = 0;
        this.gradeD = 0;
        this.gradeF = 0;
        this.passCount = 0;
        this.failCount = 0;
    }

    // Method to calculate grades and pass/fail statistics
    public void calculateGrades() {
        for (Student student : students) {
            switch (student.getGrade()) {
                case 'A':
                    gradeA++;
                    passCount++;
                    break;
                case 'B':
                    gradeB++;
                    passCount++;
                    break;
                case 'C':
                    gradeC++;
                    passCount++;
                    break;
                case 'D':
                    gradeD++;
                    passCount++;
                    break;
                case 'F':
                    gradeF++;
                    failCount++;
                    break;
            }
        }
    }

    // Method to display the grade summary using JOptionPane
    public void displayGradeSummary() {
        String gradeSummary = "Grade Summary:\n" +
                "Grade A: " + gradeA + "\n" +
                "Grade B: " + gradeB + "\n" +
                "Grade C: " + gradeC + "\n" +
                "Grade D: " + gradeD + "\n" +
                "Grade F: " + gradeF + "\n";
        JOptionPane.showMessageDialog(null, gradeSummary);
    }

    // Method to display pass and fail counts using JOptionPane
    public void displayPassFailCount() {
        String passFailSummary = "Number of students who passed: " + passCount + "\n" +
                "Number of students who failed: " + failCount;
        JOptionPane.showMessageDialog(null, passFailSummary);
    }

    // Getters for pass and fail counts
    public int getPassCount() {
        return passCount;
    }

    public int getFailCount() {
        return failCount;
    }
}
