package gradingsystem2;
        
import javax.swing.JOptionPane;

public class GradingSystem2 {
    public static void main(String[] args) {
        String continueProgram;

        do {
            // Input number of students
            String numStudentsInput = JOptionPane.showInputDialog(null, "Enter the number of students:");
            int numberOfStudents = Integer.parseInt(numStudentsInput);

            // Create an array to hold student objects
            Student[] students = new Student[numberOfStudents];

            // Input marks for each student using JOptionPane
            for (int i = 0; i < numberOfStudents; i++) {
                String markInput = JOptionPane.showInputDialog(null, "Enter mark for student " + (i + 1) + ":");
                int mark = Integer.parseInt(markInput);
                students[i] = new Student(mark);
            }

            // Create a GradeCalculator object and calculate grades
            GradeCalculator calculator = new GradeCalculator(students);
            calculator.calculateGrades();

            // Display grade summary
            calculator.displayGradeSummary();
            // Display pass and fail count
            calculator.displayPassFailCount();

            // Bonus to instructor or not
            if (calculator.getPassCount() > calculator.getFailCount()) {
                JOptionPane.showMessageDialog(null, "Bonus to instructor!");
            } else {
                JOptionPane.showMessageDialog(null, "No bonus to instructor.");
            }

            // Ask if the user wants to input another set of students
            continueProgram = JOptionPane.showInputDialog(null, "Would you like to input another set of students? (yes/no):");

        } while (continueProgram.equalsIgnoreCase("yes"));
    }
}
