import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HowToCode extends JFrame {

    // Declare components
    private JLabel welcomeLabel;
    private JTextField emailField;
    private JTextArea feedbackArea;
    private JRadioButton yesRadioButton, noRadioButton;
    private JComboBox<String> experienceComboBox;
    private JCheckBox javaCheckBox, pythonCheckBox, phpCheckBox;
    private JButton submitButton, exitButton;
    
    public HowToCode() {
        // Set the layout
        setLayout(new BorderLayout());

        // Create a panel for the image and welcome text
        JPanel headerPanel = new JPanel(new BorderLayout());
        
        // Initialize components
        Icon python = new ImageIcon("C:\\Users\\user\\Desktop\\Python-logo-notext.svg.png");
        Icon java = new ImageIcon("C:\\Users\\user\\Desktop\\Java_programming_language_logo.svg.png");
        Icon php = new ImageIcon("C:\\Users\\user\\Desktop\\PHP-logo.svg.png");
        Icon coding = new ImageIcon("C:\\Users\\user\\Desktop\\images.jpeg");
        
        // Create a label for the image
        JLabel imageLabel = new JLabel(coding, JLabel.CENTER);

        // Create a label for the welcome text
        welcomeLabel = new JLabel("Welcome to how to code!", JLabel.CENTER);
        
        // Add the image and the text to the header panel
        headerPanel.add(imageLabel, BorderLayout.NORTH); // Add image on top
        headerPanel.add(welcomeLabel, BorderLayout.SOUTH); // Add welcome text below the image

        // Add the header panel to the frame
        add(headerPanel, BorderLayout.NORTH);

        // Main content area using a GridLayout
        JPanel contentPanel = new JPanel(new GridLayout(0, 2, 5, 5)); // 0 rows, 2 columns, with 5px gap
        
        // Initialize other components
        emailField = new JTextField(20); // 20 column width
        feedbackArea = new JTextArea(5, 20); // 5 rows, 20 columns for the textarea
        feedbackArea.setLineWrap(true); // Wrap lines for better readability
        feedbackArea.setWrapStyleWord(true);
        JScrollPane feedbackScrollPane = new JScrollPane(feedbackArea); // Scrollpane for better textarea UX
        
        yesRadioButton = new JRadioButton("Yes");
        noRadioButton = new JRadioButton("No");
        ButtonGroup radioGroup = new ButtonGroup();
        radioGroup.add(yesRadioButton);
        radioGroup.add(noRadioButton);
        
        String[] experienceLevels = {"Beginner", "Intermediate", "Expert"};
        experienceComboBox = new JComboBox<>(experienceLevels);
        
        javaCheckBox = new JCheckBox("Java");
        pythonCheckBox = new JCheckBox("Python");
        phpCheckBox = new JCheckBox("PHP");
        
        submitButton = new JButton("I want to learn coding");
        exitButton = new JButton("Exit");

        // Add components to the content panel, one question/label and its input on each line
        contentPanel.add(new JLabel("Email:"));
        contentPanel.add(emailField);
        
        contentPanel.add(new JLabel("Do you like coding?"));
        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        radioPanel.add(yesRadioButton);
        radioPanel.add(noRadioButton);
        contentPanel.add(radioPanel);
        
        contentPanel.add(new JLabel("Your experience level:"));
        contentPanel.add(experienceComboBox);
        
        contentPanel.add(new JLabel("Preferred programming language:"));
        JPanel checkBoxPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        checkBoxPanel.add(javaCheckBox);
        checkBoxPanel.add(pythonCheckBox);
        checkBoxPanel.add(phpCheckBox);
        contentPanel.add(checkBoxPanel);
        
        // Add the textarea for coding experience
        contentPanel.add(new JLabel("Let us know if you have any coding experience:"));
        contentPanel.add(feedbackScrollPane); // Add the scrollpane instead of the textarea directly
        
        contentPanel.add(submitButton);
        contentPanel.add(exitButton);

        // Add content panel to the center of the frame
        add(contentPanel, BorderLayout.CENTER);
        
        // Action listeners
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = emailField.getText();
                String feedback = feedbackArea.getText(); // Get the text from the feedbackArea
                String likesCoding = yesRadioButton.isSelected() ? "Yes" : "No";
                String experience = (String) experienceComboBox.getSelectedItem();
                StringBuilder languages = new StringBuilder();
                
                if (javaCheckBox.isSelected()) languages.append("Java ");
                if (pythonCheckBox.isSelected()) languages.append("Python ");
                if (phpCheckBox.isSelected()) languages.append("PHP ");
                
                // Display a summary message
                JOptionPane.showMessageDialog(null, "Email: " + email + "\n" +
                        "Likes coding: " + likesCoding + "\n" +
                        "Experience level: " + experience + "\n" +
                        "Preferred languages: " + languages + "\n" +
                        "Feedback: " + feedback);
            }
        });
        
        exitButton.addActionListener(e -> System.exit(0));

        // Frame settings
        setTitle("How To Code");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }









    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        new HowToCode();
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HowToCode.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HowToCode.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HowToCode.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HowToCode.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HowToCode().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
