/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package looping;


public class TransferStatement {
    public static void main(String[] args) {
        
         
        System.out.println("Printing from 1 to 10");
        for (int i = 1; i <= 10; i++){
            if(i==5){
                System.out.println("Broke out of loop at i =" +i);
                break;
            }
       
         System.out.println(i + "\t");
        }
       
    }
}
