/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package looping;

public class ContinueExample {
    public static void main(String[] args) {
        
        System.out.println("Numbers 1 to 10");
        for(int i = 1; i <= 10; i++){
            if(i==5){
                continue;
            }
        System.out.println(i + "\t");
        }
        System.out.println("Skip printing 5");
    }
}
