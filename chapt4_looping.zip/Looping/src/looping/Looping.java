/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package looping;

/**
 *
 * @author user
 */
public class Looping {

    public static void main(String[] args) {
       System.out.println("Print number from 10 to 0");
        int count = 10;
       
       do{
    
    
           System.out.println(count--);
       }
       while(count >= 0);
}}
