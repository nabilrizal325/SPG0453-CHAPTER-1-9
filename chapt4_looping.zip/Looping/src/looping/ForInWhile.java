/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package looping;

/**
 *
 * @author user
 */
public class ForInWhile {
    public static void main(String[] args) {
        
        System.out.println("Printing from 1 to 10");
        int count = 1;
        while(count <= 10){
            System.out.println(count);
            count++;
        }
    }
}
