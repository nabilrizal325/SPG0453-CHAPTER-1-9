package averagemarkcalculator;

public class AverageMarkCalculator {
    public static void main(String[] args) {
        // Create objects for input and average calculation
        Display input = new Display();
        AverageCalculator calculator = new AverageCalculator();
        
        // Get marks and calculate averages
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter marks for Student " + (i + 1) + ":");
            double[] marks = input.getMarks();
            double average = calculator.calculateAverage(marks);
            calculator.storeAverage(average, i);
            System.out.println("Average for Student " + (i + 1) + " = " + average);
        }
        
        // Display the highest average
        calculator.highestAverage();
    }
}
