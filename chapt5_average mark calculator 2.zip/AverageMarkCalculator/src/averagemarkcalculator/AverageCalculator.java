package averagemarkcalculator;

public class AverageCalculator {
    double[] averages = new double[3];  // Store the three averages
    
    // Method to calculate the average for a student
    public double calculateAverage(double[] marks) {
        return (marks[0] + marks[1] + marks[2]) / 3;
    }
    
    // Method to store the average in the array
    public void storeAverage(double average, int index) {
        averages[index] = average;
    }
    
    // Method to find and print the highest average
    public void highestAverage() {
        double highest = Math.max(averages[0], Math.max(averages[1], averages[2]));  // Find the highest
        System.out.println("The highest average mark is: " + highest);
    }
}
