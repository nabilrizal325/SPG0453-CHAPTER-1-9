package averagemarkcalculator;

import java.util.Scanner;

public class Display {
    Scanner input = new Scanner(System.in);
    
    // Method to get the marks from the user
    public double[] getMarks() {
        double[] marks = new double[3];
        
        System.out.print("Mark 1: ");
        marks[0] = input.nextDouble();
        
        System.out.print("Mark 2: ");
        marks[1] = input.nextDouble();
        
        System.out.print("Mark 3: ");
        marks[2] = input.nextDouble();
        
        return marks;  // Return the marks as an array
    }
}
