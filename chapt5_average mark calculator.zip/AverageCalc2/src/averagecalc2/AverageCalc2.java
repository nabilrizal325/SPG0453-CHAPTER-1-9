package averagecalc2;

import java.util.Scanner;

public class AverageCalc2 {
    Scanner input = new Scanner(System.in);
    
    double[] averages = new double[3];  // Store the three averages
    
    // Method to calculate average marks for a single student
    public double calculateAverage() {
        System.out.print("Enter Mark 1: ");
        double mark1 = input.nextDouble();
        
        System.out.print("Enter Mark 2: ");
        double mark2 = input.nextDouble();
        
        System.out.print("Enter Mark 3: ");
        double mark3 = input.nextDouble();
        
        return (mark1 + mark2 + mark3) / 3;  // Calculate and return the average
    }
    
    // Method to get averages for 3 students
    public void inputMarksAndCalculateAverages() {
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter marks for Student " + (i + 1) + ":");
            averages[i] = calculateAverage();  // Store the average in the array
            System.out.println("Average for Student " + (i + 1) + " = " + averages[i]);
        }
    }
    
    // Method to find and print the highest average
    public void highestAverage() {
        double highest = Math.max(averages[0], Math.max(averages[1], averages[2]));  // Find the highest
        System.out.println("The highest average mark is: " + highest);
    }
    
    public static void main(String[] args) {
        AverageCalc2 calculator = new AverageCalc2();
        
        // Calculate and display averages for 3 students
        calculator.inputMarksAndCalculateAverages();
        
        // Display the highest average
        calculator.highestAverage();
    }
}
