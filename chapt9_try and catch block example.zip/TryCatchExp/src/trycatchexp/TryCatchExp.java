/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trycatchexp;

/**
 *
 * @author user
 */
public class TryCatchExp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int x=1;
        int y=0;
		try
		{
		int result = x/y;
                System.out.println(result);//may throw exception 
		}
             // handling the exception
		catch(Exception e)
		{
                  // displaying the custom message
			System.out.println("Can't divided by zero");
                }
    }
	


    
    
}
